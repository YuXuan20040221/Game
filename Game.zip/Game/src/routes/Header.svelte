<script>
	
</script>

<header>
	<script src="https://kit.fontawesome.com/86e57103de.js" crossorigin="anonymous"></script>
	<div id="info_button">
		<i class="fa-solid fa-circle-question" ></i>
	</div>
</header>

<style>
	#info_button{
		display:flex;
		justify-content: flex-end;
		color:azure;
		font-size: 20px;
	}
</style>
